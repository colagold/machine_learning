# apriori-pandas
simple apriori for pandas dataframe on Python 3.5.2

